import math


def handle_client():
    print(
        "Welcome to the Calculator v2!\nWith improved security so you can have access to all the fun math stuff and the bad guys cannot do the bad stuff! Enjoy :D"
    )

    # We added this to prevent the user from calling dangerous functions
    safe_globals = {
        "__builtins__": {
            "sin": math.sin,
            "cos": math.cos,
            "tan": math.tan,
            "asin": math.asin,
            "acos": math.acos,
            "atan": math.atan,
            "sqrt": math.sqrt,
            "pow": math.pow,
            "abs": abs,
            "round": round,
            "min": min,
            "max": max,
            "sum": sum,
        }
    }

    text = ""
    while text != "exit":
        text = input(">>> ")
        # In all ctf writeups they use _ or its unicode equivalent to somehow escape the jail. No _ means no fun for them
        for character in ["_", "＿"]:
            if character in text.lower():
                print("Not allowed, killing\n")
                text = "lol"
        try:
            print(eval(text, safe_globals))
        except Exception as e:
            print("Error: " + str(e) + "\n")


def main():
    handle_client()


if __name__ == "__main__":
    main()
