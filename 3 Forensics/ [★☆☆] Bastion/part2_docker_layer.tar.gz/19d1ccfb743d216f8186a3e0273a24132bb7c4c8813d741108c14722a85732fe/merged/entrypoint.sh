# syslogd -C2048 && \
# touch /var/lib/logrotate/status && \
# while true; do \
#     logrotate -v -f /etc/logrotate.d/authlog; \
#     sleep 60; \
# done & \
# /usr/sbin/sshd -D

syslog-ng -F &
touch /var/lib/logrotate/status

while true; do
    logrotate -v -f /etc/logrotate.d/authlog
    sleep 60
done &

/usr/sbin/sshd -D
