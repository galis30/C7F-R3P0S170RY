# ssh bastion repo

## how to build
`docker build -t ssh-bastion:latest .`

## how to run
`docker run -d --name ssh-bastion -p 22:22 ssh-bastion:latest`
or run using `docker-compose.yml`
`docker compose up -d --build`
