import socket
import json
import threading
import sys
import random
import os
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

b = 0
p = 298211241770542957242152607176537420651
a = p - 1
G = (107989946880060598496111354154766727733, 36482365930938266418306259893267327070)

def modinv(a, p):
    if a == 0:
        raise ZeroDivisionError("Inverse does not exist")
    lm, hm = 1, 0
    low, high = a % p, p
    while low > 1:
        ratio = high // low
        nm = hm - lm * ratio
        new = high - low * ratio
        lm, low, hm, high = nm, new, lm, low
    return lm % p

def ec_add(P, Q, a, p):
    if P is None:
        return Q
    if Q is None:
        return P

    x1, y1 = P
    x2, y2 = Q

    if x1 == x2 and y1 == y2:
        if y1 == 0:
            return None
        s = (3 * x1 * x1 + a) * modinv(2 * y1, p) % p
    else:
        if x1 == x2:
            return None
        s = (y2 - y1) * modinv(x2 - x1, p) % p

    x3 = (s * s - x1 - x2) % p
    y3 = (s * (x1 - x3) - y1) % p
    return (x3, y3)

def ec_scalar_mult(k, P, a, p):
    result = None
    addend = P

    while k:
        if k & 1:
            result = ec_add(result, addend, a, p)
        addend = ec_add(addend, addend, a, p)
        k >>= 1
    return result

def int_to_bytes(x):
    return x.to_bytes((x.bit_length() + 7) // 8 or 1, 'big')

def aes_encrypt(plaintext: bytes, key: bytes) -> bytes:
    key = key[:32]
    iv = os.urandom(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ciphertext = cipher.encrypt(pad(plaintext, AES.block_size))
    return iv + ciphertext

def aes_decrypt(ciphered: bytes, key: bytes) -> bytes:
    key = key[:32]
    iv = ciphered[:16]
    ciphertext = ciphered[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = unpad(cipher.decrypt(ciphertext), AES.block_size)
    return plaintext

def send_point(sock, point):
    if point is None:
        s = "None"
    else:
        s = f"{point[0]},{point[1]}"
    sock.sendall(s.encode())

def recv_point(sock):
    data = sock.recv(1024).decode().strip()
    if data == "None":
        return None
    x_str, y_str = data.split(",")
    return (int(x_str), int(y_str))

def send_messages(sock, key):
    try:
        while True:
            msg = input()
            if msg.lower() == "exit":
                break
            cipher = aes_encrypt(msg.encode(), key)
            with open("cache_send.jsonl", "a") as f:
                f.write(json.dumps({
                        "send": cipher.hex()
                    }))
                f.write("\n")
            sock.sendall(cipher)
    except Exception as e:
        print("Send error:", e)
    finally:
        sock.close()

def receive_messages(sock, key):
    try:
        while True:
            data = sock.recv(4096)  
            if not data:
                break
            with open("cache_recv.jsonl", "a") as f:
                f.write(json.dumps({
                        "recv": data.hex()
                    }))
                f.write("\n")
            plain = aes_decrypt(data, key)
            print("Peer:", plain.decode())
    except Exception as e:
        print("Receive error:", e)
    finally:
        sock.close()

def run_server():
    server_priv = random.randint(p // 2, p - 1)
    server_pub = ec_scalar_mult(server_priv, G, a, p)

    HOST = "0.0.0.0"
    PORT = 65432
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen(1)
        conn, addr = s.accept()
        with conn:
            send_point(conn, server_pub)
            client_pub = recv_point(conn)
            with open("cache.jsonl", "a") as f:
                f.write(json.dumps({
                        "server_pub": server_pub,
                        "client_pub": client_pub
                    }))
                f.write("\n")
            shared_point = ec_scalar_mult(server_priv, client_pub, a, p)
            if shared_point is None:
                return
            shared_key = int_to_bytes(shared_point[0])

            send_thread = threading.Thread(target=send_messages, args=(conn, shared_key))
            recv_thread = threading.Thread(target=receive_messages, args=(conn, shared_key))
            send_thread.start()
            recv_thread.start()
            send_thread.join()
            recv_thread.join()

def run_client():
    client_priv = random.randint(p//2, p - 1)
    client_pub = ec_scalar_mult(client_priv, G, a, p)

    HOST = "127.0.0.1"
    PORT = 65432
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        server_pub = recv_point(s)
        send_point(s, client_pub)

        shared_point = ec_scalar_mult(client_priv, server_pub, a, p)
        if shared_point is None:
            return
        shared_key = int_to_bytes(shared_point[0])

        send_thread = threading.Thread(target=send_messages, args=(s, shared_key))
        recv_thread = threading.Thread(target=receive_messages, args=(s, shared_key))
        send_thread.start()
        recv_thread.start()
        send_thread.join()
        recv_thread.join()

if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ("server", "client"):
        print("Usage: python ecc_network.py [server|client]")
        sys.exit(1)

    if sys.argv[1] == "server":
        run_server()
    else:
        run_client()

